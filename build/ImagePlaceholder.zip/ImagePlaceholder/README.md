# ImagePlaceholder for a-blog cms

a-blog cms Ver.2.8.0より拡張アプリ「ImagePlaceholder」を利用できるようになります。

## ダウンロード
[ImagePlaceholder for a-blog cms](https://github.com/appleple/acms-image-placeholder/raw/master/build/ImagePlaceholder.zip)

